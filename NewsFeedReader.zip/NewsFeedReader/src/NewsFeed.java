import java.awt.Image;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.InputStream;
import java.net.URLEncoder;
import java.net.URL;

import javax.swing.JFrame;

import javax.imageio.ImageIO;

import com.google.gson.*;

import acm.graphics.GImage;


public class NewsFeed {
	
	private JsonElement jse;
	private Image xKcdImage;
	
	public NewsFeed()
	{
		try
		{
			
			URL newsURL;
			
				//xkcdURL = new URL("http://xkcd.com/" + comicNum + "/info.0.json");
			//http://api.nytimes.com/svc/news/v3/content/nyt/u.s/24.json?&limit=5&api-key=####
			
			newsURL = new URL("https://api.nytimes.com/svc/news/v3/content/nyt/u.s./48.json?api-key=" + NYTimes.apiKey);
			//newsURL = new URL("http://api.nytimes.com/svc/news/v3/content/nyt/u.s/24.json?&limit=5&api-key=" + NYTimes.apiKey);
			System.out.println(newsURL);
			
			InputStream is = newsURL.openStream();
			BufferedReader br = new BufferedReader(new InputStreamReader(is));
			
			// Read the result into a JSON Element
			jse = new JsonParser().parse(br);
			
			//Close the connection
			is.close();
			br.close();
	
		}
		catch(java.io.UnsupportedEncodingException uee)
		{
			uee.printStackTrace();
		}
		catch(java.net.MalformedURLException mue)
		{
			mue.printStackTrace();
		}
		catch(java.io.IOException ioe)
		{
			ioe.printStackTrace();
		}
		
		if(jse != null)
		{
			//System.out.println(jse.toString());
		}
		
	}
	

	public static void main(String [] args)
	{
		NewsFeed x  = new NewsFeed();
		System.out.println(x.getHeadline(0));
//		System.out.println(x.getHeadline(1));
//		System.out.println(x.getHeadline(2));
//		System.out.println(x.getHeadline(3));
//		System.out.println(x.getHeadline(4));
		
		
	}
	
	public String getHeadline(int i)
	{
		return jse.getAsJsonObject().get("results").getAsJsonArray().get(i).getAsJsonObject().get("title").getAsString();
		
 	}

	public GImage getImage(int i) {
		// TODO Auto-generated method stub
		
		try
		{
			
		
		URL url = new URL(jse.getAsJsonObject().get("results")
				.getAsJsonArray().get(i).getAsJsonObject().
				get("multimedia").getAsJsonArray().
				get(2).getAsJsonObject()
				.get("url").getAsString());
		
		GImage g = new GImage(ImageIO.read(url));
		
		return g;

		}catch(java.net.MalformedURLException mue)
		{
			mue.printStackTrace();
			
		}
		catch(java.io.IOException ioe)
		{
			ioe.printStackTrace();
		}
		
		
		return null;

	}

}

import javax.swing.JPanel;


public class Panel
{
	public static JPanel createPanel(String type, NewsFeed nf)
	{
		if (type.equals("headlines"))
		{
			return new Headlines(nf);
		}
		else if (type.equals("media"))
		{
			return new Media(nf);
		}
		else
		{
			return null;
		}
	}
}
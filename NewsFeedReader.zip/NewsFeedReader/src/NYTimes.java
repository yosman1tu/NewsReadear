
//import java.lang.String;

public class NYTimes {
	
	public static final String apiKey = "bb34627c30ed4c30a6d660c400864cbc";
	
	//public static final String apiKey = "c35921133a5f211e369e13149c3fc27a";
	//public static final String apiKey = "e12eb227f77045a68a4babdcf2234f29";
	
	//c35921133a5f211e369e13149c3fc27a
	
	
	//http://api.nytimes.com/svc/news/v3/content/section-list.json?api-key=bb34627c30ed4c30a6d660c400864cbc
}

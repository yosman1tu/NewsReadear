
import java.awt.Color;
import java.awt.Dimension;

import javax.swing.JLabel;
import javax.swing.JPanel;

import acm.graphics.GCanvas;
import acm.graphics.GOval;


public class Headlines extends JPanel
{
	private GCanvas canvas; 
	private NewsFeed newsfeed;
	
	public Headlines(NewsFeed nf)
	{
		this.newsfeed = nf;
		this.setPreferredSize(new Dimension(300, 500));
		
		canvas = new GCanvas();
		canvas.setPreferredSize(new Dimension(300, 500));
		this.add(canvas);
		
		draw();
		
		this.setBackground(Color.white);
		


	}
	
	public void draw()
	{
		for (int i = 0; i < 6; i++)
		{
			String headline = newsfeed.getHeadline(i);
			JLabel h = new JLabel("<html>" + headline + "</html>");
			h.setPreferredSize(new Dimension(270, 60));
			canvas.add(h, 10, i * 80);
		}
	}
}
//package defaul;


import acm.gui.*;
import acm.program.*;
import acm.graphics.*;
import javax.swing.*;
import java.awt.event.*;
import java.awt.Color;
import java.awt.Font;

public class GUI extends Program
{
    // TextFields that both methods need to access
    private JPanel left;
    private JPanel right;
    
    private NewsFeed nf;
    // TODO Add slider control to window
    
    // The NYTimes
    // TODO
    //private XKCD x;
    
    // Constructor. Calls init(), then sets the size of the
    // window.
    public GUI()
    {
        // TODO x = new NYTimes("");
        this.start();
        this.setSize(600, 600);
    }
    
    public void init()
    {
        HPanel contentArea = new HPanel();
        nf = new NewsFeed();
        left = Panel.createPanel("headlines", nf);
        right = Panel.createPanel("media", nf);
        contentArea.add(left);
        contentArea.add(right);
        
        this.add(contentArea);
        

        
        addActionListeners();
    }
    
    public void actionPerformed(ActionEvent e)
    {
        String cmd = e.getActionCommand();
        if (cmd.equals("load"))
        {

        }
    }
    
    public static void main(String[] args)
    {
    	new GUI();
    }
    
    public NewsFeed getNewsFeed()
    {
    	return nf;
    }
}
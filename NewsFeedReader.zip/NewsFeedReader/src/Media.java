
import java.awt.Color;
import java.awt.Dimension;

import javax.swing.JPanel;

import acm.graphics.GCanvas;
import acm.graphics.GImage;


public class Media extends JPanel
{
	private NewsFeed newsfeed;
	private GCanvas canvas;
	
	public Media(NewsFeed nf)
	{
		this.newsfeed = nf;
		this.setPreferredSize(new Dimension(300, 500));
		this.setBackground(Color.white);
		
		canvas = new GCanvas();
		this.add(canvas);
		canvas.setPreferredSize(new Dimension(300, 500));
		
		GImage headlineImage = nf.getImage(0);
		canvas.add(headlineImage, 10, 10);
		
		GImage headlineImage2 = nf.getImage(1);
		canvas.add(headlineImage2, 10, 250);
		
	}
}